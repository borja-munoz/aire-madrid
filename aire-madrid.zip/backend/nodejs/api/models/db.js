var sqlite3 = require('sqlite3').verbose();
var fs = require("fs");
var Estacion = require("./Estacion.js");

function abrirConexion(modo)
{
    const fs = require('fs');

    const path = 'D:\\home\\site\\wwwroot\\data\\aire-madrid.db';
    //const path = '..\\..\\..\\..\\data\\aire-madrid.db';

    try 
    {
        if (fs.existsSync(path)) 
        {
            console.log("Existe");
        }
        else
        {
            console.log("Fichero no existe: " + path + " - " + __dirname);
            return(null);
        }
    } 
    catch(err) 
    {
        console.log(err);
        return(null);
    }
    console.log("Tratando de conectar");
    conexion = new sqlite3.Database(path, modo, (err) => 
    {
        if (err) 
        {
            console.error(err.message);
            return(null);
        }
        else
        {
            console.log('Conectado a la base de datos');
        }
    });

    return(conexion);
}

function cerrarConexion(conexion)
{
    conexion.close((err) => 
    {
        if (err) 
        {
            console.error(err.message);
        }
        console.log('Conexión a la base de datos cerrada');
    });
}

// Función que recupera el último fichero disponible y actualiza la base de datos
function actualizarDatos()
{
    var ultimosDatos = obtenerUltimosDatos();
    ultimosDatos.then(function(result)
    {
        // Actualizamos la base de datos Sqlite
    }, 
    function(err) 
    {
        console.log(err);
    });
}

function obtenerUltimosDatos()
{
    var request = require('request');
    var options = {
        url: 'https://datos.madrid.es/egob/catalogo/212531-10515086-calidad-aire-tiempo-real.csv',
        headers: {'User-Agent': 'node.js',
                  'Accept': 'text/csv'}
    };
    return new Promise(function(resolve, reject) 
    {
        // Do async job
        request.get(options, function(err, resp, body) 
        {
            if (err) 
            {
                reject(err);
            } 
            else 
            {
                console.log("Actualizando datos en tiempo real");
                var csvFile = body;
                var csv = require("csvtojson");
                // Convert a csv file with csvtojson
                csv({"delimiter": ";"})
                .fromString(csvFile)
                .then(function(jsonArrayObj)
                { 
                    //when parse finished, result will be emitted here.
                    resolve(jsonArrayObj); 
                })
            }
        })
    });
}

function esNecesarioActualizarDatos()
{
    // Consultamos la hora de última actualización en la base de datos
    // Sqlite y actualizamos si ha pasado ya más de una hora
    var hora = obtenerHoraUltimaActualizacion();
}

function obtenerHoraUltimaActualizacion()
{

}

exports.obtenerDatosEstacion = function(id)
{
    if (esNecesarioActualizarDatos)
    {
        actualizarDatos();
    }
    
    // Hacemos la consulta a Sqlite para recuperar los datos de la estación
};

exports.obtenerEstaciones = function()
{
    var conexion;
    
    conexion = abrirConexion(sqlite3.OPEN_READONLY);

    if (conexion != null)
    {
        var consulta = "SELECT ID, CODIGO, CODIGO_ANTIGUO, NOMBRE, " +
                    "       FECHA_ALTA, FECHA_BAJA, FECHA_CAMBIO_CODIGO" + 
                    "  FROM ESTACIONES";

        return new Promise(function(resolve, reject) 
        {
            conexion.all(consulta, (err, rows) => 
            {
                if (err) 
                {
                    console.error(err.message);
                    reject(err);
                }
                else
                {
                    var estaciones = [];
                    rows.forEach((row) => 
                    {
                        estaciones.push(new Estacion(row.ID, row.CODIGO, row.CODIGO_ANTIGUO,
                                                    row.NOMBRE, 
                                                    Date.parse(row.FECHA_ALTA), 
                                                    Date.parse(row.FECHA_BAJA),
                                                    Date.parse(row.FECHA_CAMBIO_CODIGO)));
                        //console.log(row.CODIGO);
                    });
                    resolve(estaciones);
                }
            });

            cerrarConexion(conexion);
        });
    }
    else
    {
        return new Promise(function(resolve, reject) 
        {
            reject("No se ha podido abrir la conexión a la base de datos.")
        });
    }
};
